The shader graphs in this folder are used for:
- Universal Render Pipeline versions older than 12.0
- High Definition Render Pipeline versions older than 10.0
